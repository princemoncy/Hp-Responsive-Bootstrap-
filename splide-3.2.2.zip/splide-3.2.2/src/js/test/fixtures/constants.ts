/**
 * The dummy url.
 */
export const URL = 'https://test.com';

/**
 * The root and track width.
 */
export const SLIDER_WIDTH = 1280;
